package com.kellia.webtechass.service;

import com.kellia.webtechass.dao.AccountClass;
import com.kellia.webtechass.model.Account;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

public class ImplementationBy  extends UnicastRemoteObject implements ServiceBy {
    AccountClass accountClass = new AccountClass();
    public ImplementationBy() throws RemoteException {
    }

    @Override
    public void createAccount(Account account) throws RemoteException {
        accountClass.createAccount(account);
    }

    @Override
    public List<Account> fetchAllAccounts() throws RemoteException {
        return null;
    }

    @Override
    public Account loginAccount(String email, String password) {
        return accountClass.getAccountByEmail();
    }
}
