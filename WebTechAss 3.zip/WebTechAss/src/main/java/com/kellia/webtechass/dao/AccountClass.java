package com.kellia.webtechass.dao;

import com.kellia.webtechass.model.Account;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class AccountClass {


    public boolean createAccount(Account account) {
        //session //transaction //save //commit //close session
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(account);
        tx.commit();
        session.close();
        return Boolean.TRUE;
    }

    public List<Account> getAllaccounts() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hql = "FROM Account";
            Query<Account> query = session.createQuery(hql, Account.class);
            return query.list();
        } finally {
            session.close();
        }
    }

    public Account getAccountByEmail() {
        return null;
    }
}
