package com.kellia.webtechass.service;

import com.kellia.webtechass.model.Account;

import java.rmi.RemoteException;
import java.util.List;

public interface ServiceBy {
    public void createAccount(Account account) throws RemoteException;
    public List<Account> fetchAllAccounts() throws RemoteException;
    public Account loginAccount(String email, String password);

}
